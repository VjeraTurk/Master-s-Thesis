#!/bin/bash
makeindex -s 0069064924_Vjera_Turk.ist -o 0069064924_Vjera_Turk.gls 0069064924_Vjera_Turk.glo

